<?php

if (class_exists('ProjectSeven\Service'))
{
	\ProjectSeven\Service::NewInstance()->Handle();
}
