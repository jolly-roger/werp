<?php

namespace ProjectSeven\Exceptions;

/**
 * @category ProjectSeven
 * @package Exceptions
 */
class Exception extends \Exception {}
