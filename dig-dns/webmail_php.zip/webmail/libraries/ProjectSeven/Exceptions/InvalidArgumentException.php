<?php

namespace ProjectSeven\Exceptions;

/**
 * @category ProjectSeven
 * @package Exceptions
 */
class InvalidArgumentException extends Exception {}
