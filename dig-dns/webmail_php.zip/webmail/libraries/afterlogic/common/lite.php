<?php

/**
 * Copyright (C) 2002-2013 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE
 */

	$this->SetConf('WebMail/AllowUsersAddNewAccounts', false);
	$this->SetConf('WebMail/AllowOpenPGP', false);
	$this->SetConf('Calendar/AllowCalendar', false);
	$this->SetConf('Files/AllowFiles', false);
	$this->SetConf('Helpdesk/AllowHelpdesk', false);
	$this->SetConf('Contacts/GlobalAddressBookVisibility', EContactsGABVisibility::Off);	

	
