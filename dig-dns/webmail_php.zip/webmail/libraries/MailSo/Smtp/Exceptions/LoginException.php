<?php

namespace MailSo\Smtp\Exceptions;

/**
 * @category MailSo
 * @package Smtp
 * @subpackage Exceptions
 */
class LoginException extends \MailSo\Smtp\Exceptions\NegativeResponseException {}
