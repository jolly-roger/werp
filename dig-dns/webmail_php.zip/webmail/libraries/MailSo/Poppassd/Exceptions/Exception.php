<?php

namespace MailSo\Poppassd\Exceptions;

/**
 * @category MailSo
 * @package Poppassd
 * @subpackage Exceptions
 */
class Exception extends \MailSo\Base\Exceptions\Exception {}
