<?php

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class ConnectionException extends \MailSo\Net\Exceptions\Exception {}
