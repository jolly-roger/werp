<?php

namespace MailSo\Net\Exceptions;

/**
 * @category MailSo
 * @package Net
 * @subpackage Exceptions
 */
class SocketUnreadBufferException extends \MailSo\Net\Exceptions\Exception {}
