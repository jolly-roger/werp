<?php

namespace MailSo\Pop3\Exceptions;

/**
 * @category MailSo
 * @package Pop3
 * @subpackage Exceptions
 */
class RuntimeException extends \MailSo\Pop3\Exceptions\Exception {}
