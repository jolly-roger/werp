<?php

namespace MailSo\Pop3\Exceptions;

/**
 * @category MailSo
 * @package Pop3
 * @subpackage Exceptions
 */
class LoginBadCredentialsException extends \MailSo\Pop3\Exceptions\NegativeResponseException {}
