<?php

namespace MailSo\Sieve\Exceptions;

/**
 * @category MailSo
 * @package Sieve
 * @subpackage Exceptions
 */
class NegativeResponseException extends \MailSo\Sieve\Exceptions\ResponseException {}
