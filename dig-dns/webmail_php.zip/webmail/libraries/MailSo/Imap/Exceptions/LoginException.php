<?php

namespace MailSo\Imap\Exceptions;

/**
 * @category MailSo
 * @package Imap
 * @subpackage Exceptions
 */
class LoginException extends \MailSo\Imap\Exceptions\NegativeResponseException {}
