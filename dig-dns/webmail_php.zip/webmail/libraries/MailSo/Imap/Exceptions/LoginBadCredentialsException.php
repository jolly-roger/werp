<?php

namespace MailSo\Imap\Exceptions;

/**
 * @category MailSo
 * @package Imap
 * @subpackage Exceptions
 */
class LoginBadCredentialsException extends \MailSo\Imap\Exceptions\LoginException {}