<?php

namespace MailSo\Imap\Exceptions;

/**
 * @category MailSo
 * @package Imap
 * @subpackage Exceptions
 */
class RuntimeException extends \MailSo\Imap\Exceptions\Exception {}
