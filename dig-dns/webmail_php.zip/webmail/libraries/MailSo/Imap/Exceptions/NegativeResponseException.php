<?php

namespace MailSo\Imap\Exceptions;

/**
 * @category MailSo
 * @package Imap
 * @subpackage Exceptions
 */
class NegativeResponseException extends \MailSo\Imap\Exceptions\ResponseException {}
