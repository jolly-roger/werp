<?php

/*
 * Copyright (C) 2002-2013 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE
 * 
 */

class CWebMailBlankAction extends ap_CoreModuleHelper
{
	public function UsersLogin()
	{
		exit(AP_LANG_ERROR); // TODO
	}
}