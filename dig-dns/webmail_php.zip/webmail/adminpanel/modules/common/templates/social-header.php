<tr>
	<td valign="top" colspan="2">
		<b><?php echo CApi::I18N('ADMIN_PANEL/HELPDESK_SOCIAL'); ?></b>
		<br />
		<br />
	</td>
</tr>